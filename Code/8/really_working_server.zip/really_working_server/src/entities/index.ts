import { AJson } from "./a-json.entity";
import { InventoryItem } from "./inventory-item.entity";

export default [ AJson, InventoryItem ]